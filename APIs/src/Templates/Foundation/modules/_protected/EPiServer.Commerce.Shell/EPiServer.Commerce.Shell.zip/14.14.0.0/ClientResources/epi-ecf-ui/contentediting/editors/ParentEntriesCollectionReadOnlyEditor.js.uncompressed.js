﻿define("epi-ecf-ui/contentediting/editors/ParentEntriesCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",

    // epi commerce
    "./ReadOnlyCollectionEditor",
    "../viewmodel/ParentEntriesCollectionReadOnlyEditorModel",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.entryrelationscollectionreadonlyeditor"
],
function (
    //dojo
    declare,

    // epi commerce
    ReadOnlyCollectionEditor,
    ParentEntriesCollectionReadOnlyEditorModel,
    res
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/RelationCollectionEditor
        // summary:
        //      Represents the Read-only editor widget for entrie's entry relations.

        relationType: null,

        iconClass: "epi-iconCategory",

        modelType: ParentEntriesCollectionReadOnlyEditorModel,

        changeToView: "linksview",

        buttonLabel: res.editbuttontext
    });
});