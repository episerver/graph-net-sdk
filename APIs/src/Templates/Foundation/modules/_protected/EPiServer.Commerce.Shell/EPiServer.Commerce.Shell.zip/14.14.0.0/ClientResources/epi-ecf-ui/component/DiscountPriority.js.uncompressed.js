require({cache:{
'url:epi-ecf-ui/component/templates/DiscountPriority.html':"﻿<div class=\"epi-discount-priority-container\">\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-ecf-ui/widget/MarketingToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div class=\"epi-facet-filter-container\" data-dojo-attach-point=\"filters\"></div>\r\n    <div data-dojo-attach-point=\"discountList\" data-dojo-type=\"epi-ecf-ui/widget/DiscountList\" class=\"epi-discount-list-container\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/component/DiscountPriority", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/dom-geometry",
    "dojo/topic",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/dependency",
    "epi/shell/ViewSettings",
    "epi/shell/_ContextMixin",
    "epi/shell/widget/SearchBox",
    "../widget/FacetGroupList",
    "../widget/viewmodel/FacetGroupListViewModel",
// epi-cms    
    "epi-cms/contentediting/ContentEditingValidator", // in order to display validation messages on the toolbar
// resources
    "dojo/text!./templates/DiscountPriority.html",
    "epi/i18n!epi/cms/nls/commerce.components.discountpriority",
// Widgets in the template
    "../widget/MarketingToolbar",
    "../widget/DiscountList"
], function (
    array,
    declare,
    domGeometry,
    topic,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    dependency,
    ViewSettings,
    _ContextMixin,
    SearchBox,
    FacetGroupList,
    FacetGroupListViewModel,
// epi-cms
    ContentEditingValidator,
// resources
    template,
    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, ContentEditingValidator, _ContextMixin], {
        // summary:
        //      This is the initializer of Discount Priority component.

        resources: resources,

        templateString: template,

        contextTypeName: "epi.cms.contentdata",

        // _backLink: Uri
        //      The Uri to the screen would be navigated when clicking on Close button.
        _backLink: null,

        viewName: "discountpriorityview",

        postCreate: function () {
            this.inherited(arguments);

            var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");
            this.contextId = this.contextId || contentRepositoryDescriptors.marketing.roots[0];

            this._setupEvents();
            this._setupToolbar();
            this._setupFacetFilters();
        },

        startup: function () {
            this.inherited(arguments);

            if (this.discountList.model) {
                this.discountList.model.watch("hasPendingChanges", function (property, oldValue, newValue) {
                    this.toolbar.updateActionButtonStatus(this.toolbar.buttonNames.saveButton, newValue);
                }.bind(this));
            }
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            this.inherited(arguments);

            this._backLink = data && data.backLink ? data.backLink : { uri: ViewSettings.settings.defaultContext };
            // view has been updated, let's update the discount list to reflect changes
            this.discountList.updateList(true);

            // update the toolbar with the current contextId, so any error message will be displayed on the toolbar
            this.toolbar.update({
                currentContext: { id: this.contextId },
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });
        },

        resize: function () {
            // summary:
            //      Overridden to resize the discount list

            this.inherited(arguments);

            var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode);
            var filtersSize = domGeometry.getMarginBox(this.filters);
            var contentHeight = this._contentBox.h - toolbarSize.h - filtersSize.h;
            this.discountList.resize({
                h: contentHeight,
                w: this._contentBox.w
            });
        },

        _setupFacetFilters: function() {
            var facetFiltersService = dependency.resolve("epi.commerce.DiscountFacetFiltersService");
            var discountFacetSettings = {
                facetFiltersService: facetFiltersService,
                listViewModelClass: FacetGroupListViewModel
            };
            this._discountFacet = new FacetGroupList(discountFacetSettings);

            this.searchBox = new SearchBox({
                "class": "epi-search--full-width",
                placeHolder: resources.searchplaceholder,
                triggerChangeOnEnter: false
            });
            this.own(this.searchBox,
                this.searchBox.on("searchBoxChange", this._onFilterChanged.bind(this))
            );
            this.searchBox.placeAt(this._discountFacet, "first");

            this._discountFacet.placeAt(this.filters, "last");
        },

        _setupEvents: function () {
            this.own(
                topic.subscribe("/dojo/hashchange", this._onHashChanged.bind(this)),
                topic.subscribe("/epi/shell/action/viewchanged", this._onViewChanged.bind(this))
            );
        },

        _setupToolbar: function () {
            var actionButtons = this.toolbar.getActionButtons();
            actionButtons.save.action = this._onSave.bind(this);
            actionButtons.close.action = this._onClose.bind(this);

            this.toolbar.add([actionButtons.save, actionButtons.close]);

            this.toolbar.add({
                parent: "leading",
                name: "pageheader",
                label: resources.heading,
                type: "label",
                settings: {
                    "baseClass": "epi-marketing-pageheader"
                }
            });
            this.toolbar.add({
                parent: "leading",
                name: "pagedescription",
                label: resources.description,
                type: "label",
                settings: {
                    "baseClass": "epi-marketing-pagedescription"
                }
            });
        },

        _onHashChanged: function (newHash) {
            this._discountFacet.updateFacetGroupWidgets();
            this.discountList.refresh();
        },

        _onViewChanged: function(type, args, data) {
            if (data.viewName === undefined) {
                return;
            }

            if (!data.sender || !data.sender._requestContext) {
                if (data.viewName !== this.viewName) {
                        this._discountFacet.resetFilters();
                        this.searchBox.clearValue();
                } else {
                    this._discountFacet.setDefaultFilters();
                }
            }
        },

        _onSave: function () {
            var promise = this.discountList.save();
            promise.then(function (results) {
                var validationErrors = [];
                if (results) {
                    // display error messages on toolbar if any
                    array.forEach(results, function (result) {
                        if (result.successful) {
                            return true; // continue
                        }
                        array.forEach(result.properties, function (propertyError) {
                            validationErrors.push({ severity: this.severity.error, errorMessage: propertyError.validationErrors });
                        }, this);
                    }, this);
                }

                this.setGlobalErrors(validationErrors, null);
            }.bind(this));
            return promise;
        },

        _onClose: function () {
            this.discountList.clearItems();
            this.searchBox.clearValue();
            topic.publish("/epi/shell/context/request", this._backLink, { sender: this });
        },

        _onFilterChanged: function (filter) {
            this.defer(function () {
                this._discountFacet._onSelectionChanged({ "id": "name", items: [filter.trim()] });
            }.bind(this), 500);
        }
    });
});