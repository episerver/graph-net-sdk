require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/LinkEditEditor.html':"﻿<div class=\"epi-linkeditcollectionediteditor\">\r\n    <h1>${resources.title}</h1>\r\n    <div data-dojo-attach-point=\"collectionList\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/LinkEditEditor", [
    // dojo
    "dojo/_base/declare",

    // dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",

    // Resources
    "dojo/text!./templates/LinkEditEditor.html"
],
    function (
        //dojo
        declare,

        // dijit
        _Widget,
        _TemplatedMixin,

        // Resources
        template
    ) {
        return declare([_Widget, _TemplatedMixin], {

            templateString: template,

            gridCollectionType: null,

            gridCollection: null,

            _gridCollectionSettings: {},

            buildRendering: function () {
                this.inherited(arguments);

                this.gridCollection = this.gridCollectionType(this._gridCollectionSettings);

                this.own(this.gridCollection);
                this.collectionList.appendChild(this.gridCollection.domNode);
            },

            updateView: function (data) {
                // summary:
                //		Updates the view, to reflect data changes.(when opening this view second time)
                // tags:
                //		protected

                this.set("value", data.value);
            },

            _setValueAttr: function (value) {
                // summary:
                //      Sets value for this widget.
                // value: ContentReference
                //      Input content link to get data from.

                this.gridCollection.set("value", value);
            }
        });
    });