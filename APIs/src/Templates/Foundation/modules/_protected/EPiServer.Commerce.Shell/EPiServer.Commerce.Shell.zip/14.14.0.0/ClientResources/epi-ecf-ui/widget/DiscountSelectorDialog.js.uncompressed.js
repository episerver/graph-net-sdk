require({cache:{
'url:epi-ecf-ui/widget/templates/_SelectorDialog.html':"﻿<div>\r\n    <div class=\"epi-searchbox-container\">\r\n        <div data-dojo-attach-point=\"searchBoxContainer\"></div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"noDataMessage\" style=\"display:none\" class=\"dgrid-no-data\">${noDataMessageResources.nosearchresults}</div>\r\n    <div data-dojo-attach-point=\"listContainer\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/DiscountSelectorDialog", [
// dojo
    "dojo/_base/declare",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/dependency",
    "epi-cms/widget/SearchBox",
// epi-ecf-ui
    "../MarketingUtils",
    "./DiscountTree",
// resources
    "dojo/text!./templates/_SelectorDialog.html",
    "epi/i18n!epi/nls/commerce.widget.discountselector",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.hierachicallist"
],

function (
// dojo
    declare,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    dependency,
    SearchBox,
// epi-ecf-ui
    MarketingUtils,
    DiscountTree,
// resources
    templates,
    resources,
    noDataMessageResources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // summary:
        //      Represents the widget which contains the discount tree.
        // tags:
        //    internal product

        // templateString: [protected] String
        //      Widget's template string.
        templateString: templates,

        resources: resources,

        noDataMessageResources: noDataMessageResources,

        allowedTypes: [
            MarketingUtils.contentTypeIdentifier.salesCampaign,
            MarketingUtils.contentTypeIdentifier.promotionData
        ],

        _tree: null,

        postCreate: function () {
            this.inherited(arguments);

            var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");

            this._searchBox = this._searchBox || new SearchBox({
                innerSearchBoxClass: "epi-search--full-width",
                triggerContextChange: false,
                parameters: {
                    allowedTypes: this.allowedTypes
                },
                onItemAction: this._onSearchBoxChange.bind(this)
            }, this.searchBoxContainer);
            this.own(this._searchBox);

            this._searchBox.set("area", "Commerce/Campaigns");
            this._searchBox.set("searchRoots", contentRepositoryDescriptors.marketing.roots[0]);

            this._tree = this._tree || new DiscountTree({
               root: this.root,
               store: this.store
            }, this.listContainer);

            this.own(this._tree);
        },

        _setExcludedLinkAttr: function (value) {
            this._tree.model.set("excludedLink", value);
        },

        _setCheckedItemsAttr: function (value) {
            this._tree.set("checkedItems", value);
        },

        _getCheckedItemsAttr: function () {
            return this._tree.get("checkedItems");
        },

        _onSearchBoxChange: function (item) {
            // summary:
            //      handle searchBoxChange event.
            // item: [object]
            //      the item found.
            // tags:
            //      Private

            if (item && item.metadata) {
                this._tree.setNodeChecked(item.metadata);
            }
        }
    });
});