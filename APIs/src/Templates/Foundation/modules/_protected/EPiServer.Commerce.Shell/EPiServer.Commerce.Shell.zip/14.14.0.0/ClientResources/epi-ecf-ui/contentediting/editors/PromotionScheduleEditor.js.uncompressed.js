require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/PromotionScheduleEditor.html':"﻿<div>\r\n    <div class=\"epi-form-container__section__row\">\r\n        <div>\r\n            <input type=\"radio\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-attach-point=\"useCampaignDateButton\" name=\"useCampaignDateGroup_${id}\" id=\"useCampaignButton_${id}\" />\r\n            <label for=\"useCampaignButton_${id}\">${resources.usecampaigndate}</label>\r\n            <label data-dojo-attach-point=\"labelUseCampaign\" for=\"useCampaignButton_${id}\"></label>\r\n        </div>\r\n    </div>\r\n    <div class=\"epi-form-container__section__row\">\r\n        <div>\r\n            <input type=\"radio\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-attach-point=\"notUseCampaignDateButton\" name=\"useCampaignDateGroup_${id}\" id=\"notUseCampaignDateButton_${id}\" />\r\n            <label for=\"notUseCampaignDateButton_${id}\">${resources.notusecampaigndate}</label>\r\n        </div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"validDateFields\">\r\n        <div class=\"epi-form-container__section__row\">\r\n            <label for=\"validFrom_${id}\">${resources.availablefrom}</label>\r\n            <input data-dojo-type=\"epi/shell/widget/DateTimeSelectorDropDown\" data-dojo-attach-point=\"validFromSelector\" id=\"validFrom_${id}\" />\r\n        </div>\r\n        <div class=\"epi-form-container__section__row\">\r\n            <label for=\"validUntil_${id}\">${resources.expireson}</label>\r\n            <input data-dojo-type=\"epi/shell/widget/DateTimeSelectorDropDown\" data-dojo-attach-point=\"validUntilSelector\" id=\"validUntil_${id}\" />\r\n        </div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/PromotionScheduleEditor", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/string",
// dijit
    "dijit/form/RadioButton",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/epi",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/widget/DateTimeSelectorDropDown",
// commerce
    "./../viewmodel/PromotionScheduleEditorViewModel",
// template
    "dojo/text!./templates/PromotionScheduleEditor.html",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.promotionschedule"
], function (
// dojo
    declare,
    lang,
    domStyle,
    string,
// dijit
    RadioButton,
    _WidgetBase,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    epi,
    _FocusableMixin,
    _ModelBindingMixin,
    DateTimeSelectorDropDown,
// commerce
    PromotionScheduleEditorViewModel,
// template
    template,
// resources
    resources
) {

    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, _FocusableMixin], {
        // module:
        //  epi-ecf-ui/contentediting/editors/PromotionScheduleEditor
        // summary:
        //    Represents the widget to edit validUntil and validFrom.
        // tags:
        //    public

        templateString: template,

        modelType: PromotionScheduleEditorViewModel,

        resources: resources,

        modelBindingMap: {
            "useCampaignDate": ["useCampaignDate"],
            "validFrom": ["validFrom"],
            "validUntil": ["validUntil"],
            "constraints": ["constraints"],
            "campaignDateText": ["campaignDateText"]
        },

        postMixInProperties: function () {
            this.inherited(arguments);

            if (!this.model && this.modelType) {
                this.model = new this.modelType({ value: this.value });
            }
        },

        buildRendering: function () {
            this.inherited(arguments);

            this._setRangeMessages();

            this.own(
                this.useCampaignDateButton.on("change", function (value) {
                    this.model.set("useCampaignDate", value);
                    this._raiseOnChange();
                }.bind(this)),
                this.validFromSelector.on("change", function (value) {
                    this.model.set("validFrom", value);
                    this._raiseOnChange();
                }.bind(this)),
                this.validUntilSelector.on("change", function (value) {
                    this.model.set("validUntil", value);
                    this._raiseOnChange();
                }.bind(this))
            );
        },

        _setRadioButtonState: function (value) {
            this.useCampaignDateButton.set("checked", value);
            this.notUseCampaignDateButton.set("checked", !value);
        },

        _setRangeMessages: function(){
            var validFromRangeMessageAddition = string.substitute(resources.availablefromoutofrange, resources);
            this.validFromSelector.set("rangeMessage", string.substitute(resources.outofrange, { 
                prop: resources.availablefrom,
                addition: validFromRangeMessageAddition
            }));
            var expiresOnRangeMessageAddition = string.substitute(resources.expiresonoutofrange, resources);
            this.validUntilSelector.set("rangeMessage", string.substitute(resources.outofrange, {
                prop: resources.expireson,
                addition: expiresOnRangeMessageAddition
            }));
        },

        _setUseCampaignDateAttr: function (value) {
            domStyle.set(this.validDateFields, "display", value ? "none" : "");

            this._setRadioButtonState(value);

            this.validUntilSelector.set("required", !value);
            this.validFromSelector.set("required", !value);

            // Set focus to date selectors to let selector show required warning.
            if (!value) {
                if (!this.validUntilSelector.isValid()) {
                    this.validUntilSelector.focus();
                }
                if (!this.validFromSelector.isValid()) {
                    this.validFromSelector.focus();
                }
            }
        },

        _setCampaignDateTextAttr: { node: "labelUseCampaign", type: "innerText" },
            
        _setValidFromAttr: function (value) {
            this.validFromSelector.set("value", value);
            this.validUntilSelector.set("constraints", lang.mixin(this.validUntilSelector.get("constraints"), { min: this.validFromSelector.value }));
        },

        _setValidUntilAttr: function (value) {
            this.validUntilSelector.set("value", value);
            this.validFromSelector.set("constraints", lang.mixin(this.validFromSelector.get("constraints"), { max: this.validUntilSelector.value }));
        },

        _getValueAttr: function () {
            return this.model.get("value");
        },

        _setValueAttr: function (value) {
            this.model.set("value", value);
        },

        _setConstraintsAttr: function (value) {
            if (value) {
                this.validFromSelector.set("constraints", lang.mixin(this.validFromSelector.get("constraints"), value));
                this.validUntilSelector.set("constraints", lang.mixin(this.validUntilSelector.get("constraints"), value));
            }
        },

        isValid: function () {
            return this.model.get("useCampaignDate") || (this.validFromSelector.isValid() && this.validUntilSelector.isValid());
        },

        _raiseOnChange: function() {
            this.onChange(this.model.get("value"));
        },

        onChange: function (value) {
            // summary:
            //    Fired when value is changed.
            // tags:
            //    public, callback
        }
    });
});
