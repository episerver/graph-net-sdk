require({cache:{
'url:epi-ecf-ui/widget/templates/_MarketingListBase.html':"﻿<div>\r\n    <!-- the toolbar is only here to be able to resize without exceptions -->\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"dijit/_WidgetBase\" style=\"display:none\"></div>\r\n    <div data-dojo-attach-point=\"gridNode\"></div>\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/DefaultColumnHeader.html':"﻿<div class=\"epi-text-cell-wrapper\">\r\n    <span class=\"epi-text-cell\">${headingLabel}</span>\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignNameColumn.html':"﻿<div class=\"epi-text-cell-wrapper\">\r\n    <span class=\"epi-text-cell epi-text-url\" data-content-link=\"${contentLink}\">${headingLabel}</span> <br>\r\n    <span class=\"epi-secondaryText\">Campaign</span>\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/DatePeriodColumnHeader.html':"﻿<div class=\"status-label ${badgeStatus}\">${headingLabel}</div>\r\n<div>\r\n    <span class=\"epi-text-cell\"><span class=\"epi-from-date\">${fromDate}</span> - ${toDate}</span>\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionNameColumn.html':"<div class=\"epi-promotion-name-wrapper\">\r\n    <span class=\"epi-text-cell epi-text-url dojoxEllipsis\" data-content-link=\"${contentLink}\">${headingLabel}</span>\r\n    <br>\r\n    <span class=\"dijitReset dijitInline\">\r\n        <span class=\"dijitIcon epi-objectIcon ${iconClass}\"></span>\r\n        <span class=\"epi-secondaryText\">${subheadingLabel}</span>\r\n    </span>\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionStatusColumn.html':"﻿<div>\r\n    ${text} ${date}\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/RedemptionsColumn.html':"﻿<div class=\"epi-grid-column--right epi-text-cell-wrapper\">\r\n    ${redemptions}\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/TotalOrderColumn.html':"﻿<div class=\"epi-grid-column--right epi-text-cell-wrapper\">\r\n    <h3 class=\"epi-text-cell\">${totalCount}</h3>\r\n    <!-- <span class=\"epi-secondaryText\">${totalCaption}</span> -->\r\n</div>"}});
﻿define("epi-ecf-ui/widget/_MarketingListBase", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/string",
    "dojo/when",
    "dojo/topic",
// dijit
    "dgrid/tree",
// epi
    "epi/datetime",
    "epi/dependency",
    "epi/shell/dgrid/util/misc",
    "epi/shell/TypeDescriptorManager",
// epi-cms
    "epi-cms/widget/_ConfigurableContentListBase",
// epi-ecf-ui
    "../MarketingUtils",
    "./_GridRowStatusMixin",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "dojo/text!./templates/_MarketingListBase.html",
    "dojo/text!./viewmodel/templates/DefaultColumnHeader.html",
    "dojo/text!./viewmodel/templates/CampaignNameColumn.html",
    "dojo/text!./viewmodel/templates/DatePeriodColumnHeader.html",
    "dojo/text!./viewmodel/templates/PromotionNameColumn.html",
    "dojo/text!./viewmodel/templates/PromotionStatusColumn.html",
    "dojo/text!./viewmodel/templates/RedemptionsColumn.html",
    "dojo/text!./viewmodel/templates/TotalOrderColumn.html"
], function (
// dojo
    declare,
    lang,
    dojoString,
    when,
    topic,
//dijit
    tree,
// epi
    epiDate,
    dependency,
    shellMisc,
    TypeDescriptorManager,
// epi-cms
    _ConfigurableContentListBase,
// epi-ecf-ui
    MarketingUtils,
    _GridRowStatusMixin,
// resources
    resources,
    templateString,
    defaultColumnHeaderTemplate,
    campaignNameColumnTemplate,
    datePeriodColumnHeaderTemplate,
    promotionNameColumnTemplate,
    promotionStatusColumnTemplate,
    redemptionsColumnTemplate,
    totalOrderColumnTemplate
) {
    return declare([_ConfigurableContentListBase, _GridRowStatusMixin], {
        // summary:
        //      Represents the widget to support to styling a grid to display marketing item
        // tags:
        //      public

        templateString: templateString,

        storeKeyName: "epi.cms.content.light",

        // queryName: string
        //      Default query is get children
        queryName: "getchildren",

        excludeFacets: false,

        _campaignClassName: "epi-card-grid__heading",

        _promotionClassName: "epi-card-grid__content",

        currentView: null,

        getQuery: function (parentId) {
            return {
                query: this.queryName,
                referenceId: parentId,
                typeIdentifiers: this.typeIdentifiers
            };
        },

        startup: function () {
            this.inherited(arguments);

            this._facetFiltersService = this._facetFiltersService || dependency.resolve("epi.commerce.FacetFiltersService");

            this.grid.on(".dgrid-column-name .epi-text-cell:click", function (e) {
                var selectedRow = this.grid.row(e);
                if (selectedRow) {
                    var contentLink = selectedRow.id;
                    topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + contentLink }, { sender: this });
                }
            }.bind(this));

            this.refreshList();

            this.own(
                topic.subscribe("/epi/shell/action/viewchanged", this.onViewChanged.bind(this))
            );
        },

        onViewChanged: function(type, args, data) {
            this._set("currentView", data.viewName);
        },

        refreshList: function() {
            when(this.getCurrentContext()).then(function (currentContext) {
                this.grid.set("query", this.getQuery(currentContext.id, this.excludeFacets));
            }.bind(this));
        },

        getListSettings: function () {
            var settings = this.inherited(arguments);

            return lang.mixin(this.defaultGridMixin, lang.mixin(settings, {
                className: "epi-card-grid",
                store: this.store,
                selectionMode: "none",
                cellNavigation: false,
                loadingMessage: resources.loadingdiscounts,
                noDataMessage: resources.emptycampaign
            }));
        },

        getItemClass: function (item) {
            //  Override mixin class

            if (MarketingUtils.isSalesCampaign(item.typeIdentifier)) {
                return this._campaignClassName;
            } else {
                return this._promotionClassName;
            }
        },

        getItemModifier: function (item) {
            if (item.properties.status === MarketingUtils.status.expired) {
                return MarketingUtils.isSalesCampaign(item.typeIdentifier) ?
                            this.status[MarketingUtils.status.expired] :
                            this.status[MarketingUtils.status.inactive];
            } else {
                return this.inherited(arguments);
            }
        },

        getColumnSettings: function(){
            return {
                expando: tree({
                    label: "",
                    sortable: false,
                    resizable: false,
                    shouldExpand: function (row, currentLevel, expanded) {
                        if (expanded) {
                            return true;
                        }

                        return false;
                    }
                }),
                name: {
                    label: "Name",
                    sortable: false,
                    resizable: false,
                    className: "epi-grid--40 first-column-header",
                    get: this.model._getNameModel.bind(this.model),
                    formatter: this._getNameHtml.bind(this)
                },
                status: {
                    label: "Status",
                    sortable: false,
                    resizable: false,
                    className: "epi-grid--20",
                    get: this.model._getStatusModel.bind(this.model),
                    formatter: this._getStatusHtml.bind(this)
                },
                ordertotal: {
                    label: "Total Orders",
                    sortable: false,
                    resizable: false,
                    className: "epi-grid-column--right",
                    get: this.model._getTotalOrderModel.bind(this.model),
                    formatter: this._getTotalOrderHtml.bind(this)
                },
                redemptions: {
                    label: "Redemptions",
                    sortable: false,
                    resizable: false,
                    className: "epi-grid-column--right",
                    get: this.model._getStatusModel.bind(this.model),
                    formatter: this._getRedemptionHtml.bind(this)
                }
                //TODO: !!! Keep it until this column is implemented on the server
                // revenue: {
                //     label: "Revenue",
                //     className: "epi-grid--15 epi-grid-column--right",
                //     get: function (campaignItem) {
                //         return { typeIdentifier: campaignItem.typeIdentifier, revenue: campaignItem.properties.redeemedValue };
                //     },
                //     renderCell: function (item, value, node, options) {
                //         domClass.add(node, "epi-grid-column--centered");
                //         node.innerHTML = "&nbsp;";
                //     }
                // }
            };
        },

        _getTotalOrderHtml: function (model) {
            if (model.isSalesCampaign) {
                return dojoString.substitute(defaultColumnHeaderTemplate, {
                    headingLabel: model.count
                });
            }
            return dojoString.substitute(totalOrderColumnTemplate, {
                totalCount: model.count,
                totalCaption: resources.orders
            });
        },

        _getRedemptionHtml: function (statusColumnModel) {
            if (MarketingUtils.isSalesCampaign(statusColumnModel.typeIdentifier)) {
                return dojoString.substitute(defaultColumnHeaderTemplate, {
                    headingLabel: ""
                });
            }

            return dojoString.substitute(redemptionsColumnTemplate, {
                redemptions: statusColumnModel.redemptions || "0"
            });
        },

        _getStatusHtml: function (statusColumnModel) {
            this._sanitizeDates(statusColumnModel);

            if (MarketingUtils.isSalesCampaign(statusColumnModel.typeIdentifier)) {
                return dojoString.substitute(datePeriodColumnHeaderTemplate, {
                    badgeStatus: statusColumnModel.statusLabelKey,
                    headingLabel: resources.status[statusColumnModel.statusLabelKey],
                    fromDate: epiDate.toUserFriendlyString(statusColumnModel.validFrom, null, null, true),
                    toDate: epiDate.toUserFriendlyString(statusColumnModel.validUntil, null, null, true)
                });
            }

            var promotionStatus = statusColumnModel.status;
            var campaignStatus = statusColumnModel.campaignStatus;

            if (promotionStatus === MarketingUtils.status.inactive) {
                return resources.status.inactive;
            }

            if (statusColumnModel.followsCampaignSchedule || campaignStatus === MarketingUtils.status.expired || campaignStatus === MarketingUtils.status.inactive) {
                return "";
            }

            if (promotionStatus === MarketingUtils.status.active) {
                return dojoString.substitute(promotionStatusColumnTemplate, {
                    text: epiDate.toUserFriendlyString(statusColumnModel.validFrom, null, null, true) + " -",
                    date: epiDate.toUserFriendlyString(statusColumnModel.validUntil, null, null, true)
                });
            }

            return dojoString.substitute(promotionStatusColumnTemplate, {
                date: epiDate.toUserFriendlyString(this._getDate(statusColumnModel), null, null, true),
                text: this._getDateText(statusColumnModel)
            });
        },

        _sanitizeDates: function(statusColumnModel) {
            if(statusColumnModel.validFrom.getFullYear() < 1900)
            {
                statusColumnModel.validFrom = "";
            }

            if(statusColumnModel.validUntil.getFullYear() < 1900)
            {
                statusColumnModel.validUntil = "";
            }
        },

        _getDate: function (statusColumnModel) {

            if (statusColumnModel.validFrom > new Date()) {
                return statusColumnModel.validFrom;
            }

            return statusColumnModel.validUntil;
        },

        _getDateText: function (statusColumnModel) {
            var validFrom = statusColumnModel.validFrom,
                validUntil = statusColumnModel.validUntil,
                now = new Date();

            if (validFrom < now && validUntil > now) { // Currently active
                return resources.datetext.active;
            }

            if (validFrom > now) { // Pending
                return resources.datetext.pending;
            }

            return resources.datetext.expired; // Expired
        },

        _findMatches: function(label, filter) {
            var labelToLowcase = label.toLowerCase();
            var filterLength = filter.length;
            var result = [];

            for (var i = 0; i <= labelToLowcase.length - filterLength; i++) {
                if (labelToLowcase.substring(i, i + filterLength) === filter){
                    if (result.length > 0) {
                        var prevPair = result[result.length-1];
                        if (prevPair.end > i) {
                            result[result.length - 1].end = i + filterLength;
                        }
                        else {
                            result.push({start: i, end: i + filterLength});
                        }
                    }
                    else {
                        result.push({start: i, end: i + filterLength});
                    }
                }
            }

            return result;
        },

        _highlightLabel: function _highlightLabel(headingLabel) {
            headingLabel = shellMisc.htmlEncode(headingLabel);
            var filter = this._facetFiltersService.getFilters().find(function (_) {
                return _.id === 'name';
            });
            if (filter) {
                var filterValue = shellMisc.htmlEncode(filter.values[0].trim().toLowerCase());
                var substituteFindingx = this._findMatches(headingLabel, filterValue);

                for (var j = substituteFindingx.length - 1; j >= 0; j--) {
                    var _substituteFindingx$j = substituteFindingx[j];
                    var start = _substituteFindingx$j.start;
                    var end = _substituteFindingx$j.end;
                    var filterOutValue = headingLabel.substring(start, end);

                    headingLabel = headingLabel.substring(0, start) + ("<span class=\"epi-markedText\">" + filterOutValue + "</span>") + headingLabel.substring(end);
                }
            }

            return headingLabel;
        },

        _getNameHtml: function (nameColumnModel, entityModel) {
            var template = promotionNameColumnTemplate;
            
            if (MarketingUtils.isSalesCampaign(nameColumnModel.typeIdentifier)) {
                template = campaignNameColumnTemplate;
            }
            
            return dojoString.substitute(template, {
                headingLabel: this._highlightLabel(nameColumnModel.name),
                subheadingLabel: (!!nameColumnModel.group) ? resources.group[nameColumnModel.group] : resources.campaign,
                iconClass: TypeDescriptorManager.getValue(nameColumnModel.typeIdentifier, "iconClass"),
                contentLink: entityModel.contentLink
            });
        }
    });
});