define("epi-ecf-ui/command/CatalogLanguageSettings", [
// dojo
    "require",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/topic",
    "dojo/when",
// epi shell
    "epi/shell/widget/dialog/Dialog",
// epi cms
    "epi-cms/ApplicationSettings",
    "epi-cms/contentediting/command/LanguageSettings",
// commerce
// resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.contentdetails.command.languagesettings",
    "epi/i18n!epi/shell/nls/edit.languagesettings",
    "epi/i18n!epi/shell/nls/button",
    "epi/i18n!epi/nls/episerver.shared"
],
    function (
// dojo
    moduleRequire,
    declare,
    lang,
    Deferred,
    topic,
    when,
// epi shell
    Dialog,
    ApplicationSettings,
    LanguageSettings,
// commerce
// resources
    commandResources,
    uiResources,
    buttonResources,
    sharedResources
    ) {

    function LanguageSettingsViewModel(store, contentLink) {

        return {
            getLanguageSettings: function () {
                return store.get(contentLink);
            },
            saveLanguageSettings: function (settings) {
                return store.executeMethod("UpdateLanguageSettings", contentLink, {
                    availableLanguages: settings.availableLanguages,
                    id: contentLink,
                    inheritSettings: settings.inheritSettings,
                    replacementLanguages: settings.replacementLanguages,
                    fallbackLanguages: settings.fallbackLanguages
                });
            },
            onMessage: function (message) {
                // callback
            },
            onReadOnly: function (isReadOnly) {
                // callback
            }
        };
    }
    
    return declare([LanguageSettings], {
        constructor: function () {
            this.inherited(arguments);
        },
        _execute: function () {
            moduleRequire(["epi-cms-react/components/language-settings-widget", "xstyle/css!epi-cms-react/components/language-settings-widget.css"], function (LanguageSettingsWidget) {
                when(this.contentStore.get(this.model.contentData.parentLink)).then(function (parentContent) {
                    var resources = Object.assign({}, uiResources,
                        {
                            heading: lang.replace(uiResources.heading, [this.model.contentData.name]),
                            inheritsettings: parentContent ? lang.replace(uiResources.inheritsettings, [parentContent.name]) : uiResources.inheritsettings,
                            change: buttonResources.change,
                            save: buttonResources.save,
                            ok: buttonResources.ok,
                            cancel: buttonResources.cancel
                        });
                    var contentLink = this.model.contentData.contentLink;
                    var model = LanguageSettingsViewModel(this.store, contentLink);

                    var dialog;
                    model.getLanguageSettings().then(function (settings) {
                        var content = new LanguageSettingsWidget({
                            model: model,
                            resources: resources,
                            defaultSettings: settings,
                            helpLink: ApplicationSettings.userGuideUrl + "#languagesettings",
                            onDirty: function (isDirty) {
                                if (!dialog) {
                                    return;
                                }

                                dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", !isDirty);
                            }
                        });

                        var languageSettingNode = content.domNode.children[0];
                        if (languageSettingNode && languageSettingNode.children.length > 0) {
                            // Hide the header and component of available language.
                            languageSettingNode.children[2].className += " dijitHidden";
                            languageSettingNode.children[3].className += " dijitHidden";
                        }

                        dialog = new Dialog({
                            dialogClass: "epi-dialog-portrait epi-dialog-portrait__autosize epi-dialog--wide",
                            defaultActionsVisible: true,
                            confirmActionText: sharedResources.action.save,
                            content: content,
                            title: commandResources.label,
                            onCancel: function () {
                                topic.publish("/epi/cms/contentdata/updated", {
                                    contentLink: contentLink,
                                    recursive: true
                                });
                            }
                        });
                        
                        dialog.addValidator(function () {
                            var deferred = new Deferred();
                            model.saveLanguageSettings(model.settings)
                                .then(function (response) {
                                    model.onReadOnly(response.isReadOnly);
                                    dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", response.isReadOnly);

                                    if (response.messageModel && response.messageModel.text) {
                                        model.onMessage(response.messageModel);
                                    } else {
                                        topic.publish("/epi/cms/contentdata/updated", {
                                            contentLink: contentLink,
                                            recursive: true
                                        });

                                        dialog.hide();
                                    }

                                    return deferred.resolve([]);
                                }.bind(this));
                            return deferred.promise;
                        }.bind(this));

                        dialog.show();
                        dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", true);
                        model.onReadOnly(settings.isReadOnly);
                        model.onMessage(settings.messageModel);
                    });
                }.bind(this));
            }.bind(this));
        },

        _onModelChange: function () {
            this.inherited(arguments);
        }
    });
});