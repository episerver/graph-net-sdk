require({cache:{
'dijit/main':function(){
define("dijit/main", [
	"dojo/_base/kernel"
], function(dojo){
	// module:
	//		dijit/main

/*=====
return {
	// summary:
	//		The dijit package main module.
	//		Deprecated.   Users should access individual modules (ex: dijit/registry) directly.
};
=====*/

	return dojo.dijit;
});

},
'dojox/main':function(){
define("dojox/main", ["dojo/_base/kernel"], function(dojo) {
	// module:
	//		dojox/main

	/*=====
	return {
		// summary:
		//		The dojox package main module; dojox package is somewhat unusual in that the main module currently just provides an empty object.
		//		Apps should require modules from the dojox packages directly, rather than loading this module.
	};
	=====*/

	return dojo.dojox;
});
},
'content-graph/ContentGraphCmsModule':function(){
define("content-graph/ContentGraphCmsModule", [
  // dojo
  "dojo/_base/declare",
  // dijit
  "dijit/Destroyable",
  // epi
  "epi/_Module",
  "epi/dependency",
  "epi/routes",
  // content-graph
  "content-graph/ContentGraphCommandProvider",
  "content-graph/SynchronizeCommand"
],
  function (
    // dojo
    declare,
    // dijit
    Destroyable,
    // epi
    _Module,
    dependency,
    routes,
    // content-graph
    ContentGraphCommandProvider,
    SynchronizeCommand
  ) {

    // module:
    //      content-graph/ContentGraphModule
    // summary:
    //      Optimizely ContentGraphCmsModule.
    // tags:
    //      public

    return declare([_Module, Destroyable], {

      _settings: null,
      _timeInterval: 5000,
      // =======================================================================
      // Public, overrided stubs
      // =======================================================================

      constructor: function (/*Object*/settings) {
        this._settings = settings;
      },

      initialize: function () {
        // summary:
        //      Initialize module
        // tags:
        //      public, extensions

        this.inherited(arguments);

        var registry = this.resolveDependency("epi.storeregistry");
        registry.create("epi-contentgraph.contentindexing", this._getRestPath("contentindexing"));

        if(!this._settings.enableSynchronizeMenu) { return; }

        var command = new SynchronizeCommand();
        var commandregistry = dependency.resolve("epi.globalcommandregistry");
        commandregistry.registerProvider("epi.cms.publishmenu", new ContentGraphCommandProvider(command));

        this._scheduleSyncStatusUpdate(command);
      },

      _scheduleSyncStatusUpdate: function(command) {
        var me = this;
        command.updateSyncStatus()
        .then(function(success) {
          if(success) {
            setTimeout(function() {
              me._scheduleSyncStatusUpdate(command);
            }, me._timeInterval);
          }
          //if the first status check fails (401 error for example when the user session expires), stop checking
          //to avoid spamming 401 errors to server
        });
      },

      _getRestPath: function (/*String*/name) {
        // summary:
        //      Get Content Graph store REST path
        // name: [String]
        //      The current store name
        // tags:
        //      private

        return routes.getRestPath({
          moduleArea: "Optimizely.ContentGraph.Cms.NetCore",
          storeName: name
        });
      }
    });
  });

},
'content-graph/ContentGraphCommandProvider':function(){
define("content-graph/ContentGraphCommandProvider", [
  "dojo",
  "dojo/_base/declare",
  "epi/shell/command/_CommandProviderMixin",
  "content-graph/SynchronizeCommand"
],
  function (dojo, declare, _CommandProviderMixin, SynchronizeCommand) {
    return declare([_CommandProviderMixin],
    {
      // summary:
      //      Provides synchronize command to the Publish menu.
      // tags:
      //      internal

      constructor: function (command) {
        this.inherited(arguments);
        this.add("commands", command);
      }
    });
  }
);

},
'content-graph/SynchronizeCommand':function(){
define("content-graph/SynchronizeCommand", [
  "dojo/_base/declare",
  "dojo/when",
  "dojo/_base/lang",

  "epi/shell/command/_Command",
  "epi/dependency",
  "epi-cms/_ContentContextMixin",
  // resources
  "epi/i18n!epi/cms/nls/optimizely.contentgraph.editview"
],
  function (declare, when, lang, _Command, dependency, _ContentContextMixin, resources) {
    return declare([_Command, _ContentContextMixin],
    {
      // tags:
      //      public

      name: "Synchronize",
      label: resources.synchronize,
      iconClass: "epi-iconRight",
      canExecute: true,
      order: 10000,

      constructor: function () {
        var registry = dependency.resolve("epi.storeregistry");
        this.store = this.store || registry.get("epi-contentgraph.contentindexing");
      },

      _execute: function () {
        // summary:
        //      Trigger when user click on the menu item.
        // tags:
        //      protected

        when(this.getCurrentContext(), lang.hitch(this, function (context) {
          this.store.executeMethod("SynchronizeContent", null, context.id);
        }));
      },

      _onModelChange: function () {
        this.updateSyncStatus()
      },

      //returns true if the update status is successful (200 status returned from server)
      //returns false if the update failed (401 error, for example)
      updateSyncStatus: function () {
        return when(this.getCurrentContext(), lang.hitch(this, function (context) {
          return when(this.store.executeMethod("getSyncStatus", null, context.id), lang.hitch(this, function (res) {
             this.set('iconClass', res ? "epi-iconRight" : "epi-iconUpload");
             return true;//status update is successful
            }),
            function(err) {
              return false;//status update failed due to server errors
            }
          )
        }));
      }
    });
  }
);

}}});
// wrapped by build app
define("content-graph/packaged", ["dojo","dijit","dojox"], function(dojo,dijit,dojox){
/* This is for collecting all needed modules for bundling/minifying */

});
