/* Collects all dependencies to be excluded when bundling */
define("content-graph/ExcludedDeps", [
    "dijit/Destroyable",
    "epi/_Module",
    "epi/routes",
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/command/_Command",
    "epi-cms/_ContentContextMixin"
], 1);
