define([
  // dojo
  "dojo/_base/declare",
  "dojo/when",

  // epi
  "epi/shell/command/_Command",
  "epi/routes",
  "epi/dependency",
  "epi/shell/TypeDescriptorManager",

  // epi-cms
  "epi-cms/core/ContentReference",

  // welcome integration
  "../tracking/tracker",

  // resources
  "epi/i18n!epi/cms/nls/episerver.welcomedamintegration"
], function (
  // dojo
  declare,
  when,

  // epi
  _Command,
  routes,
  dependency,
  TypeDescriptorManager,

  // epi-cms
  ContentReference,

  // welcome integration
  tracker,

  // resources
  resources
) {

  return declare([_Command], {
    // summary:
    //		Shell module implementation.
    //
    // tags:
    //      internal

    iconClass: "dijitNoIcon",
    label: "",
    isAvailable: true,
    canExecute: true,

    settings: null,
    moduleArea: null,
    assetTypes: null,

    _store: null,

    onExecuted: function (contentReference) {
      // callback
    },

    postscript: function () {
      this.inherited(arguments);

      var registry = dependency.resolve("epi.storeregistry");
      this._store = registry.create("episerver.cms.dam.integration.store." + this.moduleArea, routes.getRestPath({ moduleArea: this.moduleArea, storeName: this.settings.storeName }));
      var iconClass = this.settings && this.settings.iconClass || "epi-iconObjectExternalLink";
      this.label = (resources.command.provider.dam.label + "<span class=\"dijitInline dijitIcon dijitMenuItemIcon {0}\" data-dojo-attach-point=\"iconNode\"></span>").replace("{0}", iconClass);
    },

    _onModelChange: function () {
      if (!this.model || !this.settings.availableTypes) {
        return;
      }

      var types = TypeDescriptorManager.getValidAcceptedTypes(this.settings.availableTypes.split(","), this.model.allowedTypes, this.model.restrictedTypes);
      if (types && types.length > 0) {
        return;
      }

      this.set("isAvailable", false);
    },

    _execute: function () {
      var host = this.settings.endpoint;
      addEventListener("message", this, false);
      open(host + this.settings.pathAndQuery, "Library", "popup");

      // tracking
      this._trackEvent("openLibrayPopup");
    },

    _trackEvent: function (/*string*/eventType, /*object*/customData) {
      var eventMappings = {
        "openLibrayPopup": Object.assign({}, this.settings)
      };

      var data = customData || eventMappings[eventType];
      tracker.trackEvent(eventType, data)
    },

    handleEvent: function (event) {
      this._trackEvent("closeLibrayPopup", event);
      if (event.origin === this.settings.endpoint && event.data && !event.data.type) {
        [].concat(event.data).forEach(function (item) {
          if (!item || !item.url) {
            return;
          }

          fetch(item.url).then(resp => {
            var contentType = [...resp.headers].filter(h => h[0] === "content-type")[0][1];
            var assetType = contentType && this.assetTypes.find(x => contentType.toString().startsWith(x.name.toLowerCase()))?.value;

            when(this._store.put({ externalUrl: item.url, title: item.title, assetType: assetType })).then(function (result) {
              var value = new ContentReference(result.contentLink).toString();
              if (this.model && this.model.modelType && this.model.modelType === "EPiServer.Cms.Shell.UI.ObjectEditing.InternalMetadata.LinkModel") {
                value = { href: result.permanentLink, text: item.title };
              }
              this.onExecuted(value);
              removeEventListener("message", this, false);
            }.bind(this));
          });
        }.bind(this));
      }
    }
  });
});
