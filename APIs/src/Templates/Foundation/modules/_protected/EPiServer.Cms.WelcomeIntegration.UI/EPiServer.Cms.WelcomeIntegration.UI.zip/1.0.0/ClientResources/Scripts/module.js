define([
  // dojo
  "dojo/_base/declare",
  "dojo/when",

  // epi
  "epi/_Module",
  "epi/shell/command/_Command",
  "epi-cms/plugin-area/content-selector-plugandplay",

  // commands
  "./commands/DamContentSelect"
], function (
  // dojo
  declare,
  when,

  // epi
  _Module,
  _Command,
  pluginArea,

  // commands
  DamContentSelect
) {

  return declare([_Module], {
    // summary:
    //		Shell module implementation.
    //
    // tags:
    //      internal

    _settings: null,

    constructor: function (settings) {
      this._settings = settings;
    },

    initialize: function () {
      // summary:
      //		Initialize module

      return when(this.inherited(arguments)).then(function () {

        var options = this._settings.options;
        if (!options || !options.enabled || !options.settings) {
          return;
        }

        var that = this;
        for (var key in options.settings) {
          if (options.settings.hasOwnProperty(key)) {
            var settings = options.settings[key];
            if (settings) {
              pluginArea.add(new DamContentSelect({
                settings: settings,
                moduleArea: that._settings.name,
                assetTypes: that._settings.assetTypes
              }));
            }
          }
        }
      }.bind(this));
    }
  });
});
