using EPiServer.PlugIn;
using System;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: PlugInSummary("http://www.optimizely.com", LicensingMode.CustomLicense)]
