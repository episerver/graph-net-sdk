﻿This folder contains all block types.

Blocks should be named with a suffix of "Block", such as "TeaserBlock" or "NewsListBlock".

Default block controls should be named with a suffix of "Control",
such as "TeaserBlockControl" or "NewsListBlockControl".