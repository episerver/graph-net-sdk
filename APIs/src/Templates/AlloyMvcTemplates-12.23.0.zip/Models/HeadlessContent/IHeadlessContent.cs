namespace AlloyMvcTemplates.Models.HeadlessContent;

/// <summary>
/// Content with no renderer.
/// </summary>
public interface IHeadlessContent
{
}
