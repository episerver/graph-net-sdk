﻿namespace AlloyTemplates.Models.Pages
{
    /// <summary>
    /// Marker interface for search implementation
    /// </summary>
    public interface ISearchPage
    {
    }
}
