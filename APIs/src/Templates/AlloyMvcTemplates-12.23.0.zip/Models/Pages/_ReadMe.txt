This folder contains all page types.

Pages should be named with a suffix of "Page", such as "StandardPage" or "ProductPage".

Default page templates should be named with a suffix of "Template", 
such as "StandardPageTemplate" or "ProductPageTemplate".
