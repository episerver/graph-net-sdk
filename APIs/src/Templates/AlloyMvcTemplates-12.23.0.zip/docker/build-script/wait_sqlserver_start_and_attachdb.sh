
sleep 120s
    echo "Connection string:" $ConnectionStrings__EPiServerDB
    echo "Site port:" $site_port
dotnet AlloyMvcTemplates.dll